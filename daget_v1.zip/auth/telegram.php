<?php
$telegram_id = "5615548596";
$id_bot = "5923807142:AAEMr0M4z95BKvZn8m4-YB7QdlcDxpp89gY";
?>
